import React from 'react';
import ReactDOM from 'react-dom';

import App from './App';
import {BrowserRouter,Route,render} from 'react-router-dom'
import FlexList from './inbox.component';


ReactDOM.render(
<BrowserRouter>
<div className="main">
<App />
<Route exact path='/Inbox' component={FlexList} style={{"padding-left":"600px"}}></Route>
</div>


</BrowserRouter>, document.getElementById('root'));

