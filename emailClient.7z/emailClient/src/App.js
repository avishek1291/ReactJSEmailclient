import React, { Component } from 'react';
import {Link,Route,Switch,render} from 'react-router-dom';
import logo from './logo.svg';
import './App.css';
import BrowserRouter from 'react-router-dom/BrowserRouter';

class App extends Component {
  state={
    Actions:[{name:"Inbox",id:0},{name:"Sent",id:1},{name:"Trash",id:2},{name:"Spam",id:3}]
  }
  render() {
    return (
      <div>

<div id="mySidenav" className="sidenav">
<button className="compbutn">Compose</button>
   <ul >{this.state.Actions.map(a=>{
    return (
      <div>
      <div className="inner-li">
      <li className="a" key={a.id}><Link  className="a" to={'/'+a.name}>{a.name}</Link></li>
      </div>
     
      </div>
     
      );
  })}
  </ul>
</div>





<div id="main">
</div>
      </div>
     
    );
  }
}

export default App;
